"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNotifications } from "./useNotifications";

type Conversation = {
  character: string;
  player: string;
  lastAt: string;
  lastBody: string;
  lastDirection: "incoming" | "outgoing";
  incomingCount: number;
  totalCount: number;
};

type CharacterInfo = {
  character: string;
  total: number;
  incoming: number;
  pendingOut: number;
  lastAt: string;
};

type WindowStatus = {
  character: string;
  windowTitle: string;
  online: boolean;
  foreground: boolean;
  matched: boolean;
};

type Message = {
  id: number;
  character: string;
  player: string;
  direction: "incoming" | "outgoing";
  body: string;
  status: string;
  error: string | null;
  createdAt: string;
  sentAt: string | null;
};

const POLL_MS = 2000;
const ALL = "__ALL__";

function timeAgo(iso: string): string {
  const d = new Date(iso).getTime();
  const diff = Date.now() - d;
  if (diff < 60_000) return "agora";
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h`;
  return `${Math.floor(diff / 86_400_000)}d`;
}

function statusBadge(status: string): { label: string; classes: string } {
  switch (status) {
    case "pending":
      return {
        label: "aguardando envio",
        classes: "bg-amber-500/20 text-amber-300 border border-amber-500/40",
      };
    case "sent":
      return {
        label: "enviado no jogo",
        classes:
          "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40",
      };
    case "failed":
      return {
        label: "falhou",
        classes: "bg-rose-500/20 text-rose-300 border border-rose-500/40",
      };
    case "received":
      return { label: "recebido", classes: "" };
    default:
      return { label: status, classes: "" };
  }
}

// Deterministic-ish color for a character label based on its name.
function charColor(name: string): string {
  const palette = [
    "bg-sky-500/20 text-sky-300 border-sky-500/40",
    "bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/40",
    "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
    "bg-orange-500/20 text-orange-300 border-orange-500/40",
    "bg-lime-500/20 text-lime-300 border-lime-500/40",
    "bg-cyan-500/20 text-cyan-300 border-cyan-500/40",
    "bg-pink-500/20 text-pink-300 border-pink-500/40",
    "bg-violet-500/20 text-violet-300 border-violet-500/40",
    "bg-teal-500/20 text-teal-300 border-teal-500/40",
    "bg-rose-500/20 text-rose-300 border-rose-500/40",
  ];
  let h = 0;
  for (let i = 0; i < name.length; i += 1) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return palette[h % palette.length];
}

export function ChatApp() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [characters, setCharacters] = useState<CharacterInfo[]>([]);
  const [statusMap, setStatusMap] = useState<Record<string, WindowStatus>>({});
  const [totalWindowsOnline, setTotalWindowsOnline] = useState(0);
  const [characterFilter, setCharacterFilter] = useState<string>(ALL);
  const [selected, setSelected] = useState<{
    character: string;
    player: string;
  } | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [newCharacter, setNewCharacter] = useState("");
  const [newPlayer, setNewPlayer] = useState("");
  const [bridgeUp, setBridgeUp] = useState<boolean | null>(null);
  const [showNotifSettings, setShowNotifSettings] = useState(false);

  const scrollRef = useRef<HTMLDivElement | null>(null);
  const notif = useNotifications();
  const lastIncomingIdRef = useRef<number>(-1); // -1 = "priming, don't fire"

  const refreshTop = useCallback(async () => {
    try {
      const [c1, c2, c3] = await Promise.all([
        fetch("/api/conversations", { cache: "no-store" }).then((r) => r.json()),
        fetch("/api/characters", { cache: "no-store" }).then((r) => r.json()),
        fetch("/api/status", { cache: "no-store" }).then((r) => r.json()),
      ]);
      setConversations(
        (c1 as { conversations: Conversation[] }).conversations ?? [],
      );
      setCharacters((c2 as { characters: CharacterInfo[] }).characters ?? []);
      const wins =
        (c3 as { windows: Array<WindowStatus & { character: string }> })
          .windows ?? [];
      const map: Record<string, WindowStatus> = {};
      let onlineCount = 0;
      for (const w of wins) {
        if (w.online) onlineCount += 1;
        if (w.character) map[w.character] = w;
      }
      setStatusMap(map);
      setTotalWindowsOnline(onlineCount);
      setBridgeUp(true);
    } catch {
      setBridgeUp(false);
    }
  }, []);

  const fetchMessages = useCallback(
    async (character: string, player: string) => {
      const res = await fetch(
        `/api/conversations/${encodeURIComponent(character)}/${encodeURIComponent(player)}`,
        { cache: "no-store" },
      );
      const data = (await res.json()) as { messages: Message[] };
      setMessages(data.messages ?? []);
    },
    [],
  );

  useEffect(() => {
    void refreshTop();
    const id = setInterval(refreshTop, POLL_MS);
    return () => clearInterval(id);
  }, [refreshTop]);

  // Poll for new incoming whispers globally so we can fire notifications
  // even for conversations that aren't currently open.
  useEffect(() => {
    if (!notif.ready) return;
    let cancelled = false;

    const tick = async () => {
      try {
        const since = lastIncomingIdRef.current;
        const url =
          since < 0
            ? "/api/incoming/recent" // priming call — just capture the max ID
            : `/api/incoming/recent?since=${since}`;
        const res = await fetch(url, { cache: "no-store" });
        const data = (await res.json()) as {
          messages: Array<{
            id: number;
            character: string;
            player: string;
            body: string;
          }>;
          latestId: number;
        };
        if (cancelled) return;

        if (lastIncomingIdRef.current < 0) {
          // First run: don't spam notifications for every historical message.
          lastIncomingIdRef.current = data.latestId ?? 0;
          return;
        }

        for (const m of data.messages) {
          if (m.id > lastIncomingIdRef.current) {
            notif.notifyIncoming({
              character: m.character,
              player: m.player,
              body: m.body,
            });
            lastIncomingIdRef.current = m.id;
          }
        }
      } catch {
        /* silent — top-level polling will surface connection errors */
      }
    };

    void tick();
    const id = setInterval(tick, POLL_MS);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [notif]);

  useEffect(() => {
    if (!selected) {
      setMessages([]);
      return;
    }
    void fetchMessages(selected.character, selected.player);
    const id = setInterval(
      () => void fetchMessages(selected.character, selected.player),
      POLL_MS,
    );
    return () => clearInterval(id);
  }, [selected, fetchMessages]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendReply = useCallback(async () => {
    if (!selected || !draft.trim()) return;
    setSending(true);
    try {
      const res = await fetch(
        `/api/conversations/${encodeURIComponent(selected.character)}/${encodeURIComponent(selected.player)}`,
        {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ body: draft.trim() }),
        },
      );
      if (res.ok) {
        const data = (await res.json()) as { warning?: string };
        if (data.warning) {
          // Non-blocking: message was queued, just inform the user.
          alert(`⚠ Aviso de servidor:\n\n${data.warning}`);
        }
        setDraft("");
        void fetchMessages(selected.character, selected.player);
        void refreshTop();
      } else {
        const err = (await res.json()) as { error?: string };
        alert(err.error ?? "erro ao enfileirar mensagem");
      }
    } finally {
      setSending(false);
    }
  }, [selected, draft, fetchMessages, refreshTop]);

  // Compute realm mismatch warning for the currently selected conversation.
  const realmMismatch = useMemo(() => {
    if (!selected) return null;
    const cr = selected.character.includes("-")
      ? selected.character.split("-").slice(-1)[0]
      : "";
    const pr = selected.player.includes("-")
      ? selected.player.split("-").slice(-1)[0]
      : "";
    if (cr && pr && cr.toLowerCase() !== pr.toLowerCase()) {
      return { charRealm: cr, playerRealm: pr };
    }
    return null;
  }, [selected]);

  const startNewConversation = useCallback(() => {
    const c = newCharacter.trim();
    const p = newPlayer.trim();
    if (!c || !p) return;
    setSelected({ character: c, player: p });
    setNewPlayer("");
    if (!conversations.some((cv) => cv.character === c && cv.player === p)) {
      setConversations((prev) => [
        {
          character: c,
          player: p,
          lastAt: new Date().toISOString(),
          lastBody: "(nova conversa)",
          lastDirection: "outgoing",
          incomingCount: 0,
          totalCount: 0,
        },
        ...prev,
      ]);
    }
  }, [newCharacter, newPlayer, conversations]);

  const filteredConversations = useMemo(() => {
    if (characterFilter === ALL) return conversations;
    return conversations.filter((c) => c.character === characterFilter);
  }, [conversations, characterFilter]);

  const totalPendingOut = useMemo(
    () => characters.reduce((s, c) => s + c.pendingOut, 0),
    [characters],
  );

  return (
    <div className="flex h-screen w-full flex-col">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 bg-slate-900/80 px-6 py-3 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-yellow-500 to-amber-700 font-black text-slate-900 shadow">
            🥐
          </div>
          <div>
            <h1 className="text-lg font-bold leading-tight">Bakers Whisper</h1>
            <p className="text-xs text-slate-400">
              <span className="mr-2">
                <span className="inline-block h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_6px] shadow-emerald-500/60 align-middle" />{" "}
                {totalWindowsOnline} janela(s) online
              </span>
              · {characters.length} personagens · {conversations.length}{" "}
              conversas
              {totalPendingOut > 0 && (
                <span className="ml-2 rounded-full bg-amber-500/20 px-2 py-0.5 text-amber-300">
                  {totalPendingOut} pendente(s)
                </span>
              )}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span
            className={`h-2 w-2 rounded-full ${
              bridgeUp === null
                ? "bg-slate-500"
                : bridgeUp
                  ? "bg-emerald-400"
                  : "bg-rose-500"
            }`}
          />
          <span className="text-slate-400">
            {bridgeUp === null
              ? "conectando..."
              : bridgeUp
                ? "API online"
                : "sem conexão"}
          </span>
          <div className="relative ml-4">
            <button
              onClick={() => setShowNotifSettings((s) => !s)}
              className={`rounded border px-3 py-1 transition ${
                notif.prefs.sound || notif.prefs.desktop
                  ? "border-amber-500/50 bg-amber-500/10 text-amber-300"
                  : "border-slate-700 text-slate-400 hover:bg-slate-800"
              }`}
              title="Preferências de notificação"
            >
              {notif.prefs.sound ? "🔔" : "🔕"}
            </button>
            {showNotifSettings && (
              <div className="absolute right-0 top-full z-50 mt-2 w-72 rounded-lg border border-slate-700 bg-slate-900 p-4 shadow-2xl">
                <div className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400">
                  Notificações
                </div>
                <label className="flex cursor-pointer items-center justify-between py-2 text-sm">
                  <span>🔔 Som ao receber whisper</span>
                  <input
                    type="checkbox"
                    checked={notif.prefs.sound}
                    onChange={(e) => notif.setSound(e.target.checked)}
                    className="h-4 w-4 accent-amber-500"
                  />
                </label>
                <div className="mb-2 flex items-center gap-2 py-1 text-xs text-slate-400">
                  <span>Volume</span>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={notif.prefs.volume}
                    onChange={(e) =>
                      notif.setVolume(parseFloat(e.target.value))
                    }
                    className="flex-1 accent-amber-500"
                    disabled={!notif.prefs.sound}
                  />
                  <button
                    onClick={notif.testChime}
                    disabled={!notif.prefs.sound}
                    className="rounded border border-slate-700 px-2 py-0.5 text-[10px] uppercase text-slate-300 hover:bg-slate-800 disabled:opacity-40"
                  >
                    testar
                  </button>
                </div>
                <label className="flex cursor-pointer items-center justify-between py-2 text-sm">
                  <span>💻 Notificação do navegador</span>
                  <input
                    type="checkbox"
                    checked={notif.prefs.desktop}
                    onChange={(e) => void notif.setDesktop(e.target.checked)}
                    className="h-4 w-4 accent-amber-500"
                  />
                </label>
                <p className="mt-2 text-[10px] text-slate-500">
                  O som só toca em navegadores que permitem áudio após a
                  primeira interação com a página (clique/tecla).
                </p>
              </div>
            )}
          </div>
          <a
            href="/download"
            className="rounded border border-amber-500/50 bg-amber-500/10 px-3 py-1 text-amber-300 hover:bg-amber-500/20"
          >
            📥 Download
          </a>
          <a
            href="/accounts"
            className="rounded border border-emerald-500/50 bg-emerald-500/10 px-3 py-1 text-emerald-300 hover:bg-emerald-500/20"
          >
            📡 Contas
          </a>
          <a
            href="/gse"
            className="rounded border border-fuchsia-500/50 bg-fuchsia-500/10 px-3 py-1 text-fuchsia-300 hover:bg-fuchsia-500/20"
          >
            ⚙ GSE
          </a>
          <a
            href="/setup"
            className="rounded border border-slate-700 px-3 py-1 text-slate-300 hover:bg-slate-800"
          >
            Setup
          </a>
        </div>
      </header>

      {/* Character filter bar */}
      <div className="flex items-center gap-2 overflow-x-auto border-b border-slate-800 bg-slate-900/50 px-4 py-2 text-xs">
        <button
          onClick={() => setCharacterFilter(ALL)}
          className={`whitespace-nowrap rounded-full border px-3 py-1 transition ${
            characterFilter === ALL
              ? "border-amber-500 bg-amber-500/10 text-amber-300"
              : "border-slate-700 text-slate-300 hover:bg-slate-800"
          }`}
        >
          Todos ({conversations.length})
        </button>
        {characters.map((c) => {
          const st = statusMap[c.character];
          const online = st?.online;
          return (
            <button
              key={c.character}
              onClick={() => setCharacterFilter(c.character)}
              className={`flex items-center gap-1.5 whitespace-nowrap rounded-full border px-3 py-1 transition ${
                characterFilter === c.character
                  ? "border-amber-500 bg-amber-500/10 text-amber-300"
                  : `${charColor(c.character)} hover:opacity-80`
              }`}
              title={
                st
                  ? `${online ? "online" : "offline"} — ${st.windowTitle}`
                  : "janela não detectada"
              }
            >
              <span
                className={`h-2 w-2 shrink-0 rounded-full ${
                  online
                    ? "bg-emerald-400 shadow-[0_0_6px] shadow-emerald-500/60"
                    : "bg-slate-600"
                }`}
              />
              {c.character}
              {c.pendingOut > 0 && (
                <span className="rounded-full bg-amber-400 px-1.5 text-[10px] font-bold text-slate-900">
                  {c.pendingOut}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="flex w-96 flex-col border-r border-slate-800 bg-slate-900/40">
          <div className="border-b border-slate-800 p-3">
            <div className="mb-2 text-[10px] uppercase tracking-wider text-slate-500">
              Nova conversa
            </div>
            <div className="flex flex-col gap-2">
              <input
                value={newCharacter}
                onChange={(e) => setNewCharacter(e.target.value)}
                placeholder="Seu personagem (ex: Aragorn-Nemesis)"
                list="known-chars"
                className="rounded bg-slate-800 px-3 py-2 text-sm placeholder-slate-500 outline-none focus:ring-2 focus:ring-amber-500/60"
              />
              <datalist id="known-chars">
                {characters.map((c) => (
                  <option key={c.character} value={c.character} />
                ))}
              </datalist>
              <div className="flex gap-2">
                <input
                  value={newPlayer}
                  onChange={(e) => setNewPlayer(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") startNewConversation();
                  }}
                  placeholder="Whisper para: Nome-Reino"
                  className="flex-1 rounded bg-slate-800 px-3 py-2 text-sm placeholder-slate-500 outline-none focus:ring-2 focus:ring-amber-500/60"
                />
                <button
                  onClick={startNewConversation}
                  className="rounded bg-amber-600 px-3 text-sm font-semibold text-slate-900 hover:bg-amber-500"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            {filteredConversations.length === 0 && (
              <div className="p-6 text-center text-sm text-slate-500">
                Nenhuma conversa {characterFilter !== ALL && "para este personagem"}.
                <br />
                Aguarde um whisper ou inicie um novo acima.
              </div>
            )}
            {filteredConversations.map((c) => {
              const active =
                selected?.character === c.character && selected?.player === c.player;
              return (
                <button
                  key={`${c.character}::${c.player}`}
                  onClick={() =>
                    setSelected({ character: c.character, player: c.player })
                  }
                  className={`flex w-full flex-col gap-1 border-b border-slate-800/60 px-4 py-3 text-left transition ${
                    active
                      ? "bg-amber-500/10 border-l-2 border-l-amber-500"
                      : "hover:bg-slate-800/40"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate font-semibold text-slate-100">
                      {c.player}
                    </span>
                    <span className="text-[10px] uppercase tracking-wide text-slate-500">
                      {timeAgo(c.lastAt)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`shrink-0 rounded-full border px-1.5 py-0.5 text-[9px] uppercase tracking-wide ${charColor(c.character)}`}
                    >
                      {c.character}
                    </span>
                    <span className="truncate text-xs text-slate-400">
                      {c.lastDirection === "outgoing" ? "→ " : ""}
                      {c.lastBody}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        {/* Message pane */}
        <main className="flex flex-1 flex-col bg-[radial-gradient(circle_at_top,rgba(120,80,20,0.15),transparent_60%)]">
          {!selected ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 text-center text-slate-500">
              <div className="text-6xl">💬</div>
              <div>Selecione uma conversa à esquerda</div>
              <div className="text-xs">
                ou aguarde um whisper chegar em qualquer uma das suas janelas.
              </div>
            </div>
          ) : (
            <>
              <div className="border-b border-slate-800 px-6 py-3">
                <div className="text-sm text-slate-400">
                  Whisper com{" "}
                  <span className="font-bold text-amber-300">{selected.player}</span>
                </div>
                <div className="mt-1 flex items-center gap-2 text-xs">
                  <span className="text-slate-500">via</span>
                  <span
                    className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 font-mono ${charColor(selected.character)}`}
                  >
                    <span
                      className={`h-2 w-2 rounded-full ${
                        statusMap[selected.character]?.online
                          ? "bg-emerald-400 shadow-[0_0_6px] shadow-emerald-500/60"
                          : "bg-slate-600"
                      }`}
                    />
                    {selected.character}
                  </span>
                  {statusMap[selected.character]?.online ? (
                    <span className="text-emerald-400">
                      janela detectada · pronto para enviar
                    </span>
                  ) : (
                    <span className="text-rose-400">
                      janela não detectada — o envio pode falhar
                    </span>
                  )}
                </div>
                {realmMismatch && (
                  <div className="mt-2 rounded border border-rose-500/50 bg-rose-500/10 px-3 py-2 text-xs text-rose-200">
                    ⚠ <b>Servidor diferente:</b> seu personagem está em{" "}
                    <b>{realmMismatch.charRealm}</b> mas o destinatário está em{" "}
                    <b>{realmMismatch.playerRealm}</b>. A mensagem pode falhar
                    se os servidores não forem conectados.
                  </div>
                )}
              </div>

              <div
                ref={scrollRef}
                className="flex-1 space-y-3 overflow-y-auto px-6 py-4"
              >
                {messages.length === 0 && (
                  <div className="pt-12 text-center text-sm text-slate-500">
                    Sem mensagens ainda entre {selected.character} e{" "}
                    {selected.player}.
                  </div>
                )}
                {messages.map((m) => {
                  const mine = m.direction === "outgoing";
                  const badge = statusBadge(m.status);
                  return (
                    <div
                      key={m.id}
                      className={`flex ${mine ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-lg rounded-2xl px-4 py-2 shadow ${
                          mine
                            ? "bg-amber-600 text-slate-950"
                            : "bg-slate-800 text-slate-100"
                        }`}
                      >
                        <div className="whitespace-pre-wrap break-words text-sm">
                          {m.body}
                        </div>
                        <div
                          className={`mt-1 flex items-center gap-2 text-[10px] ${
                            mine ? "text-slate-900/70" : "text-slate-400"
                          }`}
                        >
                          <span>
                            {new Date(m.createdAt).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </span>
                          {mine && badge.label && (
                            <span
                              className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${badge.classes || "bg-slate-900/20"}`}
                            >
                              {badge.label}
                            </span>
                          )}
                          {m.error && (
                            <span className="text-rose-800">— {m.error}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="border-t border-slate-800 bg-slate-900/60 p-3">
                <div className="flex items-end gap-2">
                  <textarea
                    value={draft}
                    onChange={(e) => setDraft(e.target.value.slice(0, 255))}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        void sendReply();
                      }
                    }}
                    rows={2}
                    placeholder={`Responder ${selected.player} pela janela ${selected.character}...`}
                    className="flex-1 resize-none rounded-lg bg-slate-800 px-3 py-2 text-sm placeholder-slate-500 outline-none focus:ring-2 focus:ring-amber-500/60"
                  />
                  <button
                    onClick={() => void sendReply()}
                    disabled={sending || !draft.trim()}
                    className="rounded-lg bg-amber-500 px-5 py-2 text-sm font-bold text-slate-950 shadow disabled:opacity-40 hover:bg-amber-400"
                  >
                    {sending ? "..." : "Enviar"}
                  </button>
                </div>
                <div className="mt-1 flex items-center justify-between text-[10px] text-slate-500">
                  <span>
                    O Python bridge focará a janela{" "}
                    <b>{selected.character}</b> e digitará <code>/w {selected.player}</code> ...
                  </span>
                  <span>{draft.length}/255</span>
                </div>
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  );
}
